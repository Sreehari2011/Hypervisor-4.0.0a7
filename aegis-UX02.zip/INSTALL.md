# UX-02 — Prompt De-Upstreaming & Engagement Orientation (install runbook)

Kit: `UX-02-prompt-vapt-orientation.patch` (+ this file, + the port card
copy + a minimal changed-files mirror under `tree/`).

Fixes (operator findings):

1. **Identity** — `DEFAULT_AGENT_PROMPT` (the general-purpose fallback
   contract) no longer declares a Claude Code / Anthropic identity; it
   opens on the AEGIS identity like the other 23 agent surfaces.
2. **Orientation** — the three memory-compaction task templates (base /
   from / up_to), the no-tools preamble and the continuation transcript
   pointer are engagement-native VAPT texts (section 3 is now "Hosts,
   Services, Endpoints and Artifacts"; the checklist collects hosts,
   credentials, tool outputs, finding ids — not code snippets).
3. **Everything-else audit** — tool registration verified 34/34 (9
   platform / 24 VAPT / 1 task; aliases, schemas, trim valves, doctor
   thresholds all clean); replay semantics corrected and documented
   (summary-hash covers the fold's summary text — old journals verify
   unchanged; golden replay tests green on the patched tree).

Integrity: patch sha256
`2d13d2268cd551274760997dd0b615878d2309d1ea6fb95f8a246d9d91e486fe`.

## What the patch touches (9 files: 1 new, 8 modified)

```
README.md                                    (card count line)
docs/port-cards/README.md                    (UX-02 index row)
docs/port-cards/UX-02-prompt-derating.md     (NEW — the port card)
hypervisor/agents/prompts.py                 (identity + hygiene)
hypervisor/context/compact_prompts.py        (3 templates + preamble + pointer)
hypervisor/context/compact.py                (seam reinforcement wording)
scripts/port_agent_prompts.py                (anti-silent-revert guard)
tests/test_agents.py                         (UX-02 pins + no-upstream-identity test)
tests/test_context_engine.py                 (UX-02 pins + orientation test + oracle-diff update)
```

No engine surface beyond the prompt constants: journal, EKD, gate,
tools, loop, replay, TUI are untouched.

## Deploy (same shape as UX-01)

```bash
# 1. ship the kit to the VM home (NOT into the repo)
scp aegis-UX02.zip user1@vts-scanner:~

# 2. on the VM, unzip OUTSIDE the repo (build-context hygiene)
cd ~ && unzip aegis-UX02.zip -d ux02-kit

# 3. dry-run (expect: 9 files, 0 failures)
cd ~/Hypervisor/hypervisor-4.0
patch -p1 --dry-run < ~/ux02-kit/UX-02-prompt-vapt-orientation.patch

# 4. apply
patch -p1 < ~/ux02-kit/UX-02-prompt-vapt-orientation.patch

# 5. rebuild (apt layers cached; COPY + pip re-run, ~20 s)
docker compose build
```

## Verify ladder (in-container; use `python3 -m` — bare `hypervisor`
collides with the package dir via bash exec, known pre-existing issue)

```bash
# a. version + doctor untouched by this patch
docker compose run --rm aegis python3 -m hypervisor.cli --version
docker compose run --rm aegis python3 -m hypervisor.cli --doctor

# b. suite — expect 392 collected, 391 passed + 1 skipped
#    (VM baseline 390 + 2 new UX-02 tests; the skip is the
#     oracle-tree-absent byte-diff test, unchanged behavior)
docker compose run --rm aegis python3 -m pytest tests/ -q

# c. prompt-surface spot check (identity + orientation, in-container)
docker compose run --rm aegis python3 - <<'EOF'
from hypervisor.agents.prompts import DEFAULT_AGENT_PROMPT
from hypervisor.context.compact_prompts import BASE_COMPACT_TEMPLATE
assert "Anthropic" not in DEFAULT_AGENT_PROMPT
assert DEFAULT_AGENT_PROMPT.startswith(
    "You are an agent for AEGIS Hypervisor")
assert "Hosts, Services, Endpoints and Artifacts" in BASE_COMPACT_TEMPLATE
assert "development work" not in BASE_COMPACT_TEMPLATE
print("UX-02 surface check: OK")
EOF
```

## Notes

- **Old journals**: replay verification of every existing journal
  (pilots, dppm runs, golden fixtures) is unaffected — `summary_hash`
  covers the fold's summary text, never the templates. The golden
  replay tests in the suite prove this on the patched tree.
- **New folds onward** are shaped by the engagement-native templates.
- **Same-tag rebuild** repoints `aegis-hypervisor:4.0.0a6` to the new
  content; record the new image digest or fold into the a7 bump.
- Rollback: `patch -R -p1 < ~/ux02-kit/UX-02-prompt-vapt-orientation.patch`
  then rebuild.
